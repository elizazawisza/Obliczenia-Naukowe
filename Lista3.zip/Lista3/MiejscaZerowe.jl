#Eliza Zawisza
#244967

module MiejscaZerowe

include("./zadanie1.jl")
include("./zadanie2.jl")
include("./zadanie3.jl")

export mbisekcji, msiecznych, mstycznych

end  # module
